//
//  Movie.swift
//  Movie List
//
//  Created by Lambda_School_Loaner_268 on 2/7/20.
//  Copyright © 2020 Lambda School. All rights reserved.
//

import Foundation

protocol AddMovieDelegate{
    func movieWasAdded(_ movie: Movie)
}



struct Movie {
    var title: String
    var seen: Bool = false
}
